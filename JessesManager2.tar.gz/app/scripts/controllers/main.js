'use strict';

/**
 * @ngdoc function
 * @name jessesManager2App.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the jessesManager2App
 */
angular.module('jessesManager2App')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
